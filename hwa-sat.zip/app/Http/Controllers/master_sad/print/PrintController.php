<?php

namespace App\Http\Controllers\master_sad\print;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PrintController extends Controller
{
    public function bankGet()
    {
        //
    }
}
